<template>
  <div>
    <h1 class="title">{{username}}</h1>
    <input v-for="json,index in arr" :key="index" type="button" value="按钮" @click="fn(index)">
    <transition-group name="slideLeft">
      <div class="box" v-for="json,index in arr" :key="index" v-if="json.show">{{index}}</div>
    </transition-group>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      username: 'blue',
      arr: [
        {show: true},
        {show: true},
        {show: true},
        {show: true},
      ]
    }
  },
  methods: {
    fn(index){
      this.arr[index].show=!this.arr[index].show
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.box {width:300px; height:100px; background:#CCC; border:1px solid black}
</style>
