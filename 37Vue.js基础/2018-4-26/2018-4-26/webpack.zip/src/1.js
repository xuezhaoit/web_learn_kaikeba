/*import Person from './mod1';

let p=new Person('blue', 18);

p.show();
*/

import {a as var_a,b as var_b} from './mod1';

console.log(var_a, var_b);
