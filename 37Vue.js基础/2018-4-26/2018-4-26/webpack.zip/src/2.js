import css1 from './assets/1.css';

console.log(css1.toString());
