const pathlib=require('path');
const Webpack=require('webpack');
const HtmlWebpackPlugin=require('html-webpack-plugin');

module.exports={
  mode:  'development',
  entry: './src/index',
  output: {
    path:     pathlib.resolve('dest'),
    filename: 'bundle.js'
  },
  plugins: [
    new Webpack.HotModuleReplacementPlugin(),
    new HtmlWebpackPlugin({
      template: pathlib.resolve(__dirname, 'static/index.html'),
      filename: 'index.html',
      inject: 'body'
    })
  ],
  devServer: {
    contentBase:          pathlib.resolve('static'),
    port:                 8090,
    hot:                  true,
    historyApiFallback:   true
  }
};
