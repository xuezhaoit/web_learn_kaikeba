//reqire.js
//node.js的模块
/*
exports.a=12;
*/

/*
export default class {
  constructor(name, age){
    this.name=name;
    this.age=age;
  }

  show(){
    console.log(`我叫${this.name}，我${this.age}岁`);
  }
};
*/

export let a=12;
export let b=5;
