import common from './common';

window.onload=function (){
  document.onclick=function (){
    alert(common.sum(3,4));
  };
};
