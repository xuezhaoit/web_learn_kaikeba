export default {
  state: {
    title: '标题'
  },
  mutations: {
  },
  actions: {
  },
  getters: {
  }
};
