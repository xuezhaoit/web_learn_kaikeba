<template lang="html">
  <div class="rightlib cover_css">
    <div class="plan-image plan-lazyload-box">
    </div>
    <div class="index-right-second">
      <div class="plan-image plan-lazyload-box">
      </div>
    </div>
    <div class="real_time_intelligence pad_inner">
      <h3>
        <span>7×24h 快讯</span>
      </h3>
      <ul>
        <li class="real_time_wrapper">
          <span class="triangle"></span>
          <div class="con">
            <h4>
              <span class="title">标题标题标题标题</span>
            </h4>
            <div class="item0 hide show-content">
              简介简介简介简介简介简介简介
            </div>
            <div>
              <span class="time" title="时间">时间</span>
              <span class="share">
                <div class="fast-section-share-box hide-phone">
                  <span class="share-title">
                    分享至&nbsp;&nbsp;
                  </span>
                  <a class="item-weixin hide-phone">
                    <span class="icon-weixin"></span>
                    <div class="panel-weixin">
                      <section class="weixin-section">
                        <p></p>
                      </section>
                      <h3>打开微信“扫一扫”，打开网页后点击屏幕右上角分享按钮</h3>
                    </div>
                  </a>
                  <a href="#">
                    <span class="icon-sina"></span>
                  </a>
                </div>
              </span>
            </div>
          </div>
        </li>
        <li class="real_time_wrapper">
          <span class="triangle"></span>
          <div class="con">
            <h4>
              <span class="title">标题标题标题标题</span>
            </h4>
            <div class="item0 hide show-content">
              简介简介简介简介简介简介简介
            </div>
            <div>
              <span class="time" title="时间">时间</span>
              <span class="share">
                <div class="fast-section-share-box hide-phone">
                  <span class="share-title">
                    分享至&nbsp;&nbsp;
                  </span>
                  <a class="item-weixin hide-phone">
                    <span class="icon-weixin"></span>
                    <div class="panel-weixin">
                      <section class="weixin-section">
                        <p></p>
                      </section>
                      <h3>打开微信“扫一扫”，打开网页后点击屏幕右上角分享按钮</h3>
                    </div>
                  </a>
                  <a href="#">
                    <span class="icon-sina"></span>
                  </a>
                </div>
              </span>
            </div>
          </div>
        </li>
        <li class="real_time_wrapper">
          <span class="triangle"></span>
          <div class="con">
            <h4>
              <span class="title">标题标题标题标题</span>
            </h4>
            <div class="item0 hide show-content">
              简介简介简介简介简介简介简介
            </div>
            <div>
              <span class="time" title="时间">时间</span>
              <span class="share">
                <div class="fast-section-share-box hide-phone">
                  <span class="share-title">
                    分享至&nbsp;&nbsp;
                  </span>
                  <a class="item-weixin hide-phone">
                    <span class="icon-weixin"></span>
                    <div class="panel-weixin">
                      <section class="weixin-section">
                        <p></p>
                      </section>
                      <h3>打开微信“扫一扫”，打开网页后点击屏幕右上角分享按钮</h3>
                    </div>
                  </a>
                  <a href="#">
                    <span class="icon-sina"></span>
                  </a>
                </div>
              </span>
            </div>
          </div>
        </li>
        <li class="real_time_wrapper">
          <span class="triangle"></span>
          <div class="con">
            <h4>
              <span class="title">标题标题标题标题</span>
            </h4>
            <div class="item0 hide show-content">
              简介简介简介简介简介简介简介
            </div>
            <div>
              <span class="time" title="时间">时间</span>
              <span class="share">
                <div class="fast-section-share-box hide-phone">
                  <span class="share-title">
                    分享至&nbsp;&nbsp;
                  </span>
                  <a class="item-weixin hide-phone">
                    <span class="icon-weixin"></span>
                    <div class="panel-weixin">
                      <section class="weixin-section">
                        <p></p>
                      </section>
                      <h3>打开微信“扫一扫”，打开网页后点击屏幕右上角分享按钮</h3>
                    </div>
                  </a>
                  <a href="#">
                    <span class="icon-sina"></span>
                  </a>
                </div>
              </span>
            </div>
          </div>
        </li>
      </ul>
      <a class="more-fastsection" href="/newsflashes">
        浏览更多
        <span class="icon-arrow-right"></span>
      </a>
    </div>
    <div class="plan-image plan-lazyload-box"></div>
    <div class="plan-image plan-lazyload-box"></div>
    <div class="hot_article hot_posts pad_inner">
      <h3>
        <span>热门文章</span>
      </h3>
      <ul class="am-list">
        <li class="top">
          <div>
            <div class="img-cover">
              <a href="#">
                <span class="">
                  <b>Top 1</b>
                </span>
                <div class="img-cell" style="background-image: url(img/top_img1.jpg);"></div>
                <div class="article-title">
                  <div class="article-wrapper">标题标题标题标题</div>
                </div>
              </a>
            </div>
          </div>
        </li>
        <li class="top">
          <div>
            <div class="img-cover">
              <a href="#">
                <span class="top2">
                  <b>Top 2</b>
                </span>
                <div class="img-cell" style="background-image: url(img/top_img2.jpg);"></div>
                <div class="article-title">
                  <div class="article-wrapper">
                    标题标题标题标题标题
                  </div>
                </div>
              </a>
            </div>
          </div>
        </li>
        <li class="top no-billing"></li>
        <li class="top">
          <div>
            <div>
              <div class="img-left-cover">
                <a href="/p/5127646.html">
                  <span>3</span>
                  <div class="img-cell" style="background-image: url(img/top_img3.jpg);"></div>
                </a>
              </div>
              <div class="right-article">
                <h4>
                  <a href="#">
                    标题标题标题标题
                  </a>
                </h4>
                <div class="time_about" title="时间">
                  时间
                </div>
              </div>
            </div>
          </div>
        </li>
        <li class="top">
          <div>
            <div>
              <div class="img-left-cover">
                <a href="/p/5127646.html">
                  <span>3</span>
                  <div class="img-cell" style="background-image: url(img/top_img3.jpg);"></div>
                </a>
              </div>
              <div class="right-article">
                <h4>
                  <a href="#">
                    标题标题标题标题
                  </a>
                </h4>
                <div class="time_about" title="时间">
                  时间
                </div>
              </div>
            </div>
          </div>
        </li>
        <li class="top">
          <div>
            <div>
              <div class="img-left-cover">
                <a href="/p/5127646.html">
                  <span>3</span>
                  <div class="img-cell" style="background-image: url(img/top_img3.jpg);"></div>
                </a>
              </div>
              <div class="right-article">
                <h4>
                  <a href="#">
                    标题标题标题标题
                  </a>
                </h4>
                <div class="time_about" title="时间">
                  时间
                </div>
              </div>
            </div>
          </div>
        </li>
        <li class="top">
          <div>
            <div>
              <div class="img-left-cover">
                <a href="/p/5127646.html">
                  <span>3</span>
                  <div class="img-cell" style="background-image: url(img/top_img3.jpg);"></div>
                </a>
              </div>
              <div class="right-article">
                <h4>
                  <a href="#">
                    标题标题标题标题
                  </a>
                </h4>
                <div class="time_about" title="时间">
                  时间
                </div>
              </div>
            </div>
          </div>
        </li>
        <li class="top">
          <div>
            <div>
              <div class="img-left-cover">
                <a href="/p/5127646.html">
                  <span>3</span>
                  <div class="img-cell" style="background-image: url(img/top_img3.jpg);"></div>
                </a>
              </div>
              <div class="right-article">
                <h4>
                  <a href="#">
                    标题标题标题标题
                  </a>
                </h4>
                <div class="time_about" title="时间">
                  时间
                </div>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
    <div class="plan-image plan-lazyload-box"></div>
    <div class="biggie_word pad_inner">
      <h3>
        <span>今日言论</span>
      </h3>
      <div class="biggie_list">
        <ul>
          <li>
            <a href="#">
              <div class="biggie_photo" style="background-image: url(img/face1.jpg);">
              </div>
              <div class="biggie_wrapper">
                <div class="biggie_name">黄峥</div>
                <p class="biggie_content">
                  阿里京东、滴滴美团，他们是帝国式竞争，有明确地盘的界限。但我觉得我们这一代人的思路不该是这样。
                </p>
              </div>
            </a>
          </li>
          <li>
            <a href="#">
              <div class="biggie_photo" style="background-image: url(img/face1.jpg);">
              </div>
              <div class="biggie_wrapper">
                <div class="biggie_name">黄峥</div>
                <p class="biggie_content">
                  阿里京东、滴滴美团，他们是帝国式竞争，有明确地盘的界限。但我觉得我们这一代人的思路不该是这样。
                </p>
              </div>
            </a>
          </li>
          <li>
            <a href="#">
              <div class="biggie_photo" style="background-image: url(img/face1.jpg);">
              </div>
              <div class="biggie_wrapper">
                <div class="biggie_name">黄峥</div>
                <p class="biggie_content">
                  阿里京东、滴滴美团，他们是帝国式竞争，有明确地盘的界限。但我觉得我们这一代人的思路不该是这样。
                </p>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'IndexSide',
}
</script>

<style lang="css">
</style>
