<template lang="html">
  <header class="common-header J_commonHeaderWrapper">
    <div class="app-container J_appDownloadWrapper">
      <a href="#" class="open-app-button">
        立即打开
      </a>
    </div>
    <div class="container">
      <div class="pc-nav">
        <a class="logo" href="#">
          <img src="static/img/logo-a6afc.png" alt="36氪" />
        </a>
        <div class="triggers">
          <a class="headericon-header-search J_searchTrigger" href="javascript:void(0);"></a>
          <a class="headericon-header-menu J_menuTrigger" href="javascript:void(0);"></a>
        </div>
        <nav>
          <ul class="J_navList">
            <li name="mainindex">
              <a href="#">首页</a>
            </li>
            <li name="index" class="active">
              <a href="#">首页</a>
            </li>
            <li name="kaike" class="kaike">
              <a href="#">开氪</a>
            </li>
            <li name="newsflashes">
              <a href="#">
                7×24h 快讯
              </a>
            </li>
            <li class="mobile-show">
              <a href="#">
                近期活动
              </a>
            </li>
            <li class="mobile-show">
              <a href="#">
                鲸准
              </a>
            </li>
            <li class="mobile-show">
              <a href="#">
                氪空间
              </a>
            </li>
            <li class="firstlevel li-chuang pop-row-trigger">
              <a href="javascript:void(0)" class="trigger-hide">
                创业者服务
                <i class="headericon-arrow-drop-down">
                </i>
              </a>
            </li>
            <li class="firstlevel li-tou pop-row-trigger">
              <a href="javascript:void(0)" class="trigger-hide">
                投资人服务
                <i class="headericon-arrow-drop-down"></i>
              </a>
            </li>
            <li class="discover pop-row-trigger">
              <a href="javascript:void(0)" class="trigger-hide pointer-box">
                联系我们
                <i class="headericon-arrow-drop-down"></i>
              </a>
            </li>
            <li class="mobile-show"></li>
          </ul>
        </nav>
      </div>
      <div class="search-mask blackhidden">
      </div>
      <div class="right-col J_rightNavWrapper">
        <ul class="sub-nav">
          <li class="report-btn mobile-hide">
            <a href="#">
              寻求报道
            </a>
          </li>
          <li class="search-item">
            <div class="search-form-wrapper" href="javascript:void(0)">
              <div class="search-form-inner">
                <i class="headericon-Icon_Search searchdisplayico">
                </i>
                <div class="search-form-box">
                  <i class=" headericon-Icon_Search blackhidden searchico">
                  </i>
                  <form action="" class="J_searchForm">
                    <input type="text" placeholder="搜索" class="J_searchInput" />
                  </form>
                </div>
                <i class="close-search headericon-close"></i>
                <button class="do-submit">
                  搜索
                </button>
                <button class="do-submit do-submit-icon headericon-header-search">
                </button>
                <button class="headericon-close close-icon" type="button">
                </button>
              </div>
              <span>
              </span>
            </div>
          </li>
          <li class="app-download pop-row-trigger">
            <a href="#">
              <i class="headericon-Icon_App">
                <span class="path1">
                </span>
                <span class="path2">
                </span>
                <span class="path3">
                </span>
              </i>
              <span class="txt">
                客户端
              </span>
            </a>
          </li>
          <li class="login-actions">
            <div class="login">
              <div class="group">
                <i class="headericon-Icon_SignIn blackhidden">
                </i>
                <i class="headericon-header-user whitehidden">
                </i>
                <a href="javascript:void(0)" class="J_login login-link">
                  登录
                </a>
              </div>
              <b class="whitehidden">
                /
              </b>
              <div class="group">
                <i class="headericon-Icon_SignUp blackhidden">
                  <span class="path1">
                  </span>
                  <span class="path2">
                  </span>
                  <span class="path3">
                  </span>
                </i>
                <a href="javascript:void(0)" class="J_signup login-link">
                  注册
                </a>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="startup-service-pop pop-up-row mobile-hide">
      <div class="items-wrapper" style="transform: translate(0px, -100%); transition: all 0.1s ease 0.3s;">
        <a href="#" class="item">
          <span class="product-icon">
            <img src="static/img/ic_report@2x-bc294.png" />
          </span>
          <span class="product-name">
            寻求报道
          </span>
          <span class="product-desc">
            最贴心的服务，最优质的报道
          </span>
        </a>
        <a href="#" class="item">
          <span class="product-icon">
            <img src="static/img/ic_activity@2x-966df.png" />
          </span>
          <span class="product-name">
            近期活动
          </span>
          <span class="product-desc">
            提供最有价值的创投活动
          </span>
        </a>
        <a href="#" class="item">
          <span class="product-icon">
            <img src="static/img/jingzhun-logo-1-614ef.png" />
          </span>
          <span class="product-name">
            鲸准
          </span>
          <span class="product-desc">
            让每一次选择都心中有数
          </span>
        </a>
        <a href="#" class="item">
          <span class="product-icon">
            <img src="static/img/gn8pet9cnj7jc1vw.png" />
          </span>
          <span class="product-name">
            氪空间
          </span>
          <span class="product-desc">
            让办公更简单
          </span>
        </a>
      </div>
    </div>
    <div class="investor-service-pop pop-up-row mobile-hide">
      <div class="items-wrapper" style="transform: translate(0px, -100%); transition: all 0.1s ease 0.3s;">
        <a href="#" class="item">
          <span class="product-icon">
            <img src="static/img/ic_cooperation@2x-4c322.png" />
          </span>
          <span class="product-name">
            VClub投资机构合作
          </span>
          <span class="product-desc">
            助力投资机构领跑新商业时代
          </span>
        </a>
        <a href="#" class="item">
          <span class="product-icon">
            <img src="static/img/jingzhun-logo-2-3ef0e.png" />
          </span>
          <span class="product-name">
            鲸准 · 个人版
          </span>
          <span class="product-desc">
            投资人的随身数据字典
          </span>
        </a>
        <a href="#" class="item">
          <span class="product-icon">
            <img src="static/img/jingzhun-logo-3-20458.png" />
          </span>
          <span class="product-name">
            鲸准 · 机构版
          </span>
          <span class="product-desc">
            投资机构的全流程管理系统
          </span>
        </a>
      </div>
    </div>
    <div class="contact-us-pop pop-up-row mobile-hide">
      <div class="items-wrapper" style="transform: translate(0px, -100%); transition: all 0.1s ease 0.3s;">
        <a href="javascript:void(0)" class="item">
          <span class="product-icon">
            <img src="static/img/ic_submission@2x-8d888.png" />
          </span>
          <span class="product-name">
            我要投稿
          </span>
          <span class="product-desc">
            提升影响力的最有效方式
          </span>
        </a>
        <a href="javascript:void(0)" class="item"
       >
          <span class="product-icon">
            <img src="static/img/ic_cooperation2@2x-9185b.png" />
          </span>
          <span class="product-name">
            商务合作
          </span>
          <span class="product-desc">
            让品牌超越昨天，先见未来
          </span>
        </a>
        <a href="#" class="item">
          <span class="product-icon">
            <img src="static/img/1is2ilcd29dsxx07.png" />
          </span>
          <span class="product-name">
            城市加盟
          </span>
          <span class="product-desc">
            携手并进，共享红利
          </span>
        </a>
      </div>
    </div>
    <div class="app-download-pop pop-up-row mobile-hide">
      <div class="items-wrapper" style="transform: translate(0px, -100%); transition: all 0.1s ease 0.3s;">
        <a href="javascript:void(0)" class="item app-item">
          <span class="product-icon">
            <img src="static/img/ic_36kr@2x-9a9cd.png" />
          </span>
          <span class="product-name">
            36氪
          </span>
          <span class="product-download">
            <span class="product-qr">
              <img src="static/img/QR_36k@2x-c4e8e.png" />
            </span>
            <span class="product-version">
              iPhone&amp;Android
            </span>
          </span>
        </a>
        <a href="javascript:void(0)" class="item app-item">
          <span class="product-icon">
            <img src="static/img/jingzhun-logo-2-3ef0e.png" />
          </span>
          <span class="product-name">
            鲸准 · 个人版
          </span>
          <span class="product-download">
            <span class="product-qr">
              <img src="static/img/jingzhun-qrcode-3a27a.png" />
            </span>
            <span class="product-version">
              iPhone&amp;Android
            </span>
          </span>
        </a>
      </div>
    </div>
  </header>
</template>

<script>
export default {
  name: 'Header'
}
</script>

<style lang="css">
</style>
