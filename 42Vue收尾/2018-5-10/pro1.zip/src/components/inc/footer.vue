<template lang="html">
  <footer class="common-footer">
    <div class="sections">
      <section class="product-section">
        <h3>产品和服务</h3>
        <div class="items-wrapper">
          <a href="#" class="item">
            <span class="product-icon">
              <img src="static/img/ic_36kr@2x-9a9cd.png">
            </span>
            <span class="product-name">36氪媒体</span>
            <span class="product-desc">让一部分人先看到未来</span>
          </a>
          <a href="#" class="item">
            <span class="product-icon">
              <img src="static/img/4dvu0zykchyo7hs2.png">
            </span>
            <span class="product-name">氪空间</span>
            <span class="product-desc">联合办公标杆企业</span>
          </a>
          <a href="#" class="item">
            <span class="product-icon">
              <img src="static/img/jingzhun-logo-1-614ef.png">
            </span>
            <span class="product-name">鲸准</span>
            <span class="product-desc">让每一次选择都心中有数</span>
          </a>
        </div>
        <div class="feedback">
        </div>
      </section>
      <section class="link-section">
        <h3>关于36氪</h3>
        <div class="links">
          <a href="#" rel="nofollow">关于我们</a>
          <a href="#" rel="nofollow">寻求报道</a>
          <a href="javascript:void(0)" rel="nofollow">我要投稿</a>
          <a href="#" rel="nofollow">城市加盟</a>
          <a href="#" rel="nofollow">加入我们</a>
          <a href="#" rel="nofollow">APP下载</a>
        </div>
      </section>
      <section class="partner-section">
        <h3>合作伙伴</h3>
        <ul class="footer-partner">
          <li>
            <a href="#" rel="nofollow" class="external">
              <img alt="阿里云" src="static/img/aly.png">
            </a>
          </li>
          <li>
            <a href="#" rel="nofollow" class="external">
              <img alt="腾讯云" src="static/img/txyun.png">
            </a>
          </li>
          <li>
            <a href="#" rel="nofollow" class="external">
              <img alt="又拍云" src="static/img/upy.png">
            </a>
          </li>
          <li>
            <a href="#" rel="nofollow" class="external">
              <img alt="七牛云存储" src="static/img/qny.png">
            </a>
          </li>
          <li>
            <a href="#" rel="nofollow" class="external">
              <img alt="融云" src="static/img/ry.png">
            </a>
          </li>
          <li>
            <a href="#" rel="nofollow" class="external">
              <img alt="听云" src="static/img/ty.png">
            </a>
          </li>
          <li>
            <a href="#" rel="nofollow" class="external">
              <img alt="高迪传媒" src="static/img/gaodi-95fb8.png">
            </a>
          </li>
          <li>
            <a href="#" rel="nofollow" class="external">
              <img alt="上直播" src="static/img/shangzhibo-ede60.png">
            </a>
          </li>
          <li>
            <a href="#" rel="nofollow" class="external">
              <img alt="环信" src="static/img/huanxin-34376.png">
            </a>
          </li>
          <li>
            <a href="#" rel="nofollow" class="external">
              <img alt="teambition" src="static/img/teambition-9915f.png">
            </a>
          </li>
        </ul>
      </section>
      <section class="qr-section">
        <h3>36氪APP下载</h3>
        <img class="qr" alt="36氪APP下载" src="static/img/57rrbw8czufu0hqm.png">
        <div>
          iPhone &amp; Android
        </div>
      </section>
    </div>
    <div class="bottom">
      <div class="container">
        <div class="footer-logo">
          <a href="#">
            <img src="static/img/logo_white@2x-ae14b.png" alt="">
          </a>
        </div>
        <div class="copyright">
          <span class="mobile-hide">
            本站由
            <a href="#" rel="nofollow">
              <img alt="阿里云" style="height: 12px;vertical-align: middle;margin-right: -10px;margin-left: 10px;position: relative;top: -2px;" src="static/img/aliyunfooter.png">
            </a>
          </span>
          <span class="law">
            © 2011~2018 北京品新传媒文化有限公司 | 京ICP备12031756号 | 京ICP证150143号
            <span class="mobile-hide">
              |
              <a href="#">
                京公网安备11010802020581号
              </a>
            </span>
          </span>
          <a class="safe-logo" href="#">
            <img alt="品牌宝" src="static/img/gw_83x30.png">
          </a>
          <br>
        </div>
        <div class="share">
          <a class="iconfooter-weibo" href="#" rel="nofollow"></a>
          <a class="iconfooter-rss" href="#" rel="nofollow"></a>
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style lang="css">
</style>
