<template lang="html">
  <div class="article-detail" style="position: relative; z-index: 1111;">
    <div></div>
    <div class="only-article">
      <div class="center-content">
        <div class="content-wrapper">
          <div class="loading_article">
            <div>
              <div class="circle">
                <i class="icon-loading">
                </i>
              </div>
              <b>
                加载中
              </b>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ArticleDetail'
}
</script>

<style lang="css">
</style>
