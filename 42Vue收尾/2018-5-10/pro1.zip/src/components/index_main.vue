<template lang="html">
  <div class="ab-index-exp mainlib">
    <div class="center_content">
      <div class="content-wrapper">
        <div class="high_projects">
          <div class="a_ds_banner_wapper">
            <div class="space_padding"></div>
            <div class="a_ds_banner index_banner slick-initialized slick-slider" style="opacity: 1;">
              <button type="button" class="icon-angle-left slick-arrow" style="display: inline-block;"></button>
              <div class="slick-list draggable">
                <div class="slick-track" style="opacity: 1; width: 4482px;">
                  <div class="banner_cell radius has_title slick-slide" style="width: 747px; position: relative; left: 0px; top: 0px; z-index: 998; opacity: 0; transition: opacity 500ms linear;">
                    <a href="#" style="background-image: url(img/banner1.jpg);"></a>
                    <div class="info">
                      <div class="abstract">
                        巨头决战3公里生活圈：它会是2018零售业的主战场吗？
                      </div>
                    </div>
                  </div>
                  <div class="banner_cell radius has_title slick-slide" style="width: 747px; position: relative; left: -747px; top: 0px; z-index: 998; opacity: 0; transition: opacity 500ms linear;">
                    <a href="#" style="background-image: url(img/banner2.jpg);"></a>
                    <div class="mark_box">
                      <span class="mark">
                        广告
                      </span>
                    </div>
                    <div class="info">
                      <div class="abstract">
                        每一克轻皆匠心，李宁超轻15，轻驰而来
                      </div>
                    </div>
                  </div>
                  <div class="banner_cell radius has_title slick-slide" style="width: 747px; position: relative; left: -1494px; top: 0px; z-index: 998; opacity: 0; transition: opacity 500ms linear;">
                    <a href="#" style="background-image: url(img/banner3.jpg);"></a>
                    <div class="info">
                      <div class="abstract">
                        趣头条，在巨头曾经忽视的下沉市场狂奔
                      </div>
                    </div>
                  </div>
                  <div class="banner_cell radius has_title slick-slide" style="width: 747px; position: relative; left: -2241px; top: 0px; z-index: 998; opacity: 0; transition: opacity 500ms linear;">
                    <a href="#" style="background-image: url(img/banner4.jpg);"></a>
                    <div class="info">
                      <div class="abstract">
                        中国独角兽报告：周期短、创新强、爆发集中，为什么这么牛？
                      </div>
                    </div>
                  </div>
                  <div class="banner_cell radius has_title slick-slide" style="width: 747px; position: relative; left: -2988px; top: 0px; z-index: 998; opacity: 0; transition: opacity 500ms linear;">
                    <a href="#" style="background-image: url(img/banner5.jpg);"></a>
                    <div class="info">
                      <div class="abstract">
                        今日值得看——36氪全天热度文章
                      </div>
                    </div>
                  </div>
                  <div class="banner_cell radius has_title slick-slide slick-current slick-active"
                  style="width: 747px; position: relative; left: -3735px; top: 0px; z-index: 999; opacity: 1;">
                    <a href="#" style="background-image: url(img/banner6.jpg);"></a>
                    <div class="info">
                      <div class="abstract">
                        无人驾驶、免费乘坐，硅谷的出租车行业要变天了
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <button type="button" class="icon-angle-right slick-arrow" style="display: inline-block;"></button>
              <ul class="slick-dots" style="display: flex;">
                <li class="">
                  <button type="button">
                    1
                  </button>
                </li>
                <li class="">
                  <button type="button">
                    2
                  </button>
                </li>
                <li class="">
                  <button type="button">
                    3
                  </button>
                </li>
                <li class="">
                  <button type="button">
                    4
                  </button>
                </li>
                <li class="">
                  <button type="button">
                    5
                  </button>
                </li>
                <li class="slick-active">
                  <button type="button">
                    6
                  </button>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="editor_recommend_box">
          <div class="editor_recommend">
            <ul class="am-cf pc_list">
              <li class="radius">
                <div class="space_cell"></div>
                <div>
                  <a href="#">
                    <img src="static/img/heading2.jpg" alt="标题">
                  </a>
                  <div class="des am-text-break">
                    <a href="#">
                      <span>标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题</span>
                    </a>
                  </div>
                </div>
              </li>
              <li class="radius">
                <div class="space_cell"></div>
                <div>
                  <a href="#">
                    <img src="static/img/heading2.jpg" alt="标题">
                  </a>
                  <div class="des am-text-break">
                    <a href="#">
                      <span>标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题</span>
                    </a>
                  </div>
                </div>
              </li>
              <li class="radius">
                <div class="space_cell"></div>
                <div>
                  <a href="#">
                    <img src="static/img/heading2.jpg" alt="标题">
                  </a>
                  <div class="des am-text-break">
                    <a href="#">
                      <span>标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题</span>
                    </a>
                  </div>
                </div>
              </li>
            </ul>
            <div class="am-cf h5_list slick-initialized slick-slider">
              <button type="button" class="slick-prev slick-arrow" style="display: block;">Previous</button>
              <div class="slick-list draggable">
                <div class="slick-track" style="opacity: 1; width: 0px;">
                  <div class="cell slick-slide slick-current slick-active"
                  style="width: 0px; position: relative; left: 0px; top: 0px; z-index: 999; opacity: 1;">
                    <a href="#">
                      <img src="static/img/heading1_sm.jpg" alt="标题">
                      <span>标题标题标题标题标题标题标题标题</span>
                    </a>
                  </div>
                  <div class="cell slick-slide" style="width: 0px; position: relative; left: 0px; top: 0px; z-index: 998; opacity: 0; transition: opacity 500ms linear;">
                    <a href="#">
                      <img src="static/img/heading2_sm.jpg" alt="标题">
                      <span>标题标题标题标题标题标题标题标题</span>
                    </a>
                  </div>
                  <div class="cell slick-slide" style="width: 0px; position: relative; left: 0px; top: 0px; z-index: 998; opacity: 0; transition: opacity 500ms linear;">
                    <a href="#">
                      <img src="static/img/heading3_sm.jpg" alt="标题">
                      <span>标题标题标题标题标题标题标题标题</span>
                    </a>
                  </div>
                </div>
              </div>
              <button type="button" class="slick-next slick-arrow" style="display: block;">Next</button>
              <ul class="slick-dots" style="display: block;">
                <li class="slick-active">
                  <button type="button">1</button>
                </li>
                <li class="">
                  <button type="button">2</button>
                </li>
                <li class="">
                  <button type="button">3</button>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <IndexList/>
      </div>
    </div>
  </div>
</template>

<script>
import IndexList from './index_list'

export default {
  name: 'IndexMain',
  components: {IndexList}
}
</script>

<style lang="css">
</style>
