import {Routes, RouterModule} from '@angular/router'

import {CmpAComponent} from '../testComponent/cmpa.component';
import {CmpBComponent} from '../testComponent/cmpb.component';

//路由表
const routes: Routes=[
  {path: 'a/:id', component: CmpAComponent},
  {path: 'b', component: CmpBComponent},
];

/*const r2: Routes=[
  {path: '1', component: CmpA1},
  {path: '2', component: CmpA2},
];
RouterModule.forChild('a', r2);*/

export default RouterModule.forRoot(routes)
