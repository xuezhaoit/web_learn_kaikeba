import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppComonent} from './app.component';

import {ListModule} from '../list/list.module';
import {TestComponentModule} from '../testComponent/testComponent.module';
import {HttpModule} from '@angular/http';
import routes from '../routes/'

@NgModule({
  declarations: [
    AppComonent
  ],
  imports: [BrowserModule, ListModule, HttpModule, TestComponentModule, routes],
  exports: [AppComonent],
  bootstrap: [AppComonent]
})

export class AppModule{

}
