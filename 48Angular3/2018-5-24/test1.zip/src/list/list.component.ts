import {Component, OnInit} from '@angular/core';

import {Http} from '@angular/http';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})

export class ListComponent{
  private arr:Array<number>;

  constructor(private http:Http){
    //console.log(this.http);
    this.http.get('http://localhost:8080/').toPromise().then(res=>{
      //alert('成功');
      //console.log(res.json());

      this.arr=res.json();
    }, err=>{
      //alert('失败');
      console.log(err);
    });

    /*let r=this.http.get('http://localhost:8080');

    try{
      r.forEach(res=>{
        alert('成功');
        console.log(res.json());
      });
    }catch(e){
      alert('失败');
    }*/


    //console.log(res);
  }

  ngOnInit(){
    //alert(this.http);
  }
}
