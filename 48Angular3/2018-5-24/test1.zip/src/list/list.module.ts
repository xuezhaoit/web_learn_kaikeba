import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {ListComponent} from './list.component';
import {ListItemComponent} from './list_item.component';

@NgModule({
  declarations: [
    ListComponent,
    ListItemComponent
  ],
  imports: [BrowserModule],
  exports: [ListComponent]
})

export class ListModule{

}
