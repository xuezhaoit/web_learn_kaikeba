import {NgModule} from '@angular/core';
import {CmpAComponent} from './cmpa.component';
import {CmpBComponent} from './cmpb.component';

@NgModule({
  declarations: [
    CmpAComponent,
    CmpBComponent
  ],
  imports: [],
  exports: [CmpAComponent, CmpBComponent]
})

export class TestComponentModule{

}
