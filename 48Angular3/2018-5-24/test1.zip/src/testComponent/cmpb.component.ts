import {Component} from '@angular/core'

@Component({
  selector: 'cmpb',
  templateUrl: './cmpb.component.html',
  styleUrls: ['./cmpb.component.css']
})

export class CmpBComponent{

}
