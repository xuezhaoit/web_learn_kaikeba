import {Component} from '@angular/core'
import {ActivatedRoute, Params} from '@angular/router';

@Component({
  selector: 'cmpa',
  templateUrl: './cmpa.component.html',
  styleUrls: ['./cmpa.component.css']
})

export class CmpAComponent{
  constructor(private route: ActivatedRoute){
    console.log(this.route.snapshot.params.id);
  }
}
