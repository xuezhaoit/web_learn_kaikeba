import {Component} from '@angular/core';

@Component({
  selector: 'list',
  templateUrl: './list.component.html'
})

export class ListComponent{
  
}
