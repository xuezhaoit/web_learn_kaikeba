import {Component} from '@angular/core';

@Component({
  selector: 'right-cmp',
  templateUrl: './right.component.html'
})

export class RightComponent{

}
