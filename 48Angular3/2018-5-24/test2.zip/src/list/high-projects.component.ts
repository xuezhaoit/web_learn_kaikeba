import {Component} from '@angular/core';

@Component({
  selector: 'high-projects',
  templateUrl: './high-projects.component.html'
})

export class HighProjectsComponent{

}
