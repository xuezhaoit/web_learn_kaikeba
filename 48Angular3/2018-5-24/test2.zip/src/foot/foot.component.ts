import {Component} from '@angular/core';

@Component({
  selector: 'site-foot',
  templateUrl: './foot.component.html'
})

export class FootComponent{

}
