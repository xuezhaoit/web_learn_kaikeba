import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppComonent} from './app.component';

import {ListModule} from '../list/list.module'

@NgModule({
  declarations: [
    AppComonent
  ],
  imports: [BrowserModule, ListModule],
  exports: [AppComonent],
  bootstrap: [AppComonent]
})

export class AppModule{

}
