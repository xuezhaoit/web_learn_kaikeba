import {Component} from '@angular/core';

@Component({
  selector: 'list-item',
  templateUrl: './list_item.component.html',
  styleUrls: ['./list_item.component.css'],
  inputs: ['str', 'index']
})

export class ListItemComponent{
  private str;
  private index;
}
