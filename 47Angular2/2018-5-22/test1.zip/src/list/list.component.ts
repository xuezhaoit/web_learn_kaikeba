import {Component, OnInit} from '@angular/core';

import {Http} from '@angular/http';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})

export class ListComponent{
  private arr=[1,2,3,4,5,3];

  constructor(private http:Http){
    alert('a');
  }

  ngOnInit(){
    //alert(this.http);
  }
}
